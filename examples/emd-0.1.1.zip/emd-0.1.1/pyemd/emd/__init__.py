"""
Earth Mover's Distance in Python
"""
from emd import emd
